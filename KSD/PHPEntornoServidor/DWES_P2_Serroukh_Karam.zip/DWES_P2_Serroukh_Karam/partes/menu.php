<nav>
    <ul class="menu">
        <li><a href="index.php">Inicio</a></li>
        <li><a href="login.php">Inicio de sesion</a></li>
        <li><a href="singup.php">Registro</a></li>
    </ul>
</nav>

