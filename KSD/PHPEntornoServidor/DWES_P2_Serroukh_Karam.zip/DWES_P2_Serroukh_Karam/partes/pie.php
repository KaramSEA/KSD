<footer>
    <p>Karam Serroukh</p>
</footer>